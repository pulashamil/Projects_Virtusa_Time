-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 28, 2019 at 11:12 AM
-- Server version: 5.7.26
-- PHP Version: 7.2.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `desktopdb`
--
CREATE DATABASE IF NOT EXISTS `desktopdb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `desktopdb`;

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
CREATE TABLE IF NOT EXISTS `doctor` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `nic` varchar(30) NOT NULL,
  `specialization` varchar(50) NOT NULL,
  `mobile` int(11) NOT NULL,
  `hospital` varchar(50) NOT NULL,
  `fee` varchar(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `nic` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `birthday` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `mobile` int(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `possition` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `healthcustomer`
--

DROP TABLE IF EXISTS `healthcustomer`;
CREATE TABLE IF NOT EXISTS `healthcustomer` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `mobile` int(11) NOT NULL,
  `nic` varchar(30) NOT NULL,
  `birthday` varchar(30) NOT NULL,
  `guardiansname` varchar(30) NOT NULL,
  `blood` varchar(10) NOT NULL,
  `surgury` varchar(100) NOT NULL,
  `alergy` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `healthpayment`
--

DROP TABLE IF EXISTS `healthpayment`;
CREATE TABLE IF NOT EXISTS `healthpayment` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `mobile` int(11) NOT NULL,
  `nic` varchar(30) NOT NULL,
  `blood` varchar(30) NOT NULL,
  `paymenttype` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `amount` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

DROP TABLE IF EXISTS `hospital`;
CREATE TABLE IF NOT EXISTS `hospital` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `hospital` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `branches` varchar(50) NOT NULL,
  `contactno` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `openhours` varchar(30) NOT NULL,
  `website` varchar(50) NOT NULL,
  `hospitalcharge` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `motorcustomer`
--

DROP TABLE IF EXISTS `motorcustomer`;
CREATE TABLE IF NOT EXISTS `motorcustomer` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `mobile` int(11) NOT NULL,
  `nic` varchar(15) NOT NULL,
  `vehicleno` varchar(15) NOT NULL,
  `manufacturedyear` int(11) NOT NULL,
  `modelname` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `motorpayment`
--

DROP TABLE IF EXISTS `motorpayment`;
CREATE TABLE IF NOT EXISTS `motorpayment` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `nic` varchar(30) NOT NULL,
  `vehicleno` varchar(30) NOT NULL,
  `mobile` int(11) NOT NULL,
  `paymenttype` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `amount` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
