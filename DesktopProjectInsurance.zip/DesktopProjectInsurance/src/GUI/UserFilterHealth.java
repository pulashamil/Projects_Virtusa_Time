/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

/**
 *
 * @author mshamil
 */
class UserFilterHealth {
    
    private String fname;
    private int mobile;
    private String nic;
    private String gname;
    private String blood;

    public String getFname() {
        return fname;
    }

    public int getMobile() {
        return mobile;
    }

    public String getNic() {
        return nic;
    }

    public String getGname() {
        return gname;
    }

    public String getBlood() {
        return blood;
    }

    public UserFilterHealth(String fname, int mobile, String nic, String gname, String blood) {
        this.fname = fname;
        this.mobile = mobile;
        this.nic = nic;
        this.gname = gname;
        this.blood = blood;
    }
    
    
    
}
