/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

/**
 *
 * @author mshamil
 */
class Hospital {
    
    
    
    
    private int ID,contactno;
    private String name,address,branches,email,open,website,hospitalcharge;
    
   
    public Hospital(int ID,String name,String address,String branches,int contactno,String email,String open,String website,String hospitalcharge){
        
        
        this.ID=ID;
        this.name=name;
        this.address=address;
        this.branches=branches;
        this.contactno=contactno;
        this.email=email;
        this.open=open;
        this.website=website;
        this.hospitalcharge=hospitalcharge;
        
        
    }

    public int getID() {
        return ID;
    }

    public int getContactno() {
        return contactno;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getBranches() {
        return branches;
    }

    public String getEmail() {
        return email;
    }

    public String getOpen() {
        return open;
    }

    public String getWebsite() {
        return website;
    }

    public String getHospitalcharge() {
        return hospitalcharge;
    }
}
