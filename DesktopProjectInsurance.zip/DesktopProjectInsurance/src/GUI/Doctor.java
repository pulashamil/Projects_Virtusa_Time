/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

/**
 *
 * @author mshamil
 */
class Doctor {
    
     private int ID,mobile;
    private String name,nic,specialization,hospital,fee;
    
   
    public Doctor(int ID,String name,String nic,String specialization,int mobile,String hospital,String fee ){
        
        this.ID=ID;
        this.name=name;
        this.nic=nic;
        this.specialization=specialization;
        this.mobile=mobile;
        this.hospital=hospital;
        this.fee=fee;
        
        
        
        
        
        
        
    }

    public int getID() {
        return ID;
    }

    public int getMobile() {
        return mobile;
    }

    public String getName() {
        return name;
    }

    public String getNic() {
        return nic;
    }

    public String getSpecialization() {
        return specialization;
    }

    public String getHospital() {
        return hospital;
    }

    public String getFee() {
        return fee;
    }
    
    
}
