/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

/**
 *
 * @author mshamil
 */
class User {
    
    private int ID,mobile,manufacturedyear;
    private String fname,address,gender,nic,vehicleno,modelname;
    
   
    public User(int ID,String fname,String address,String gender,int mobile,String nic,String vehicleno,int manufacturedyear,String modelname ){
        
        this.ID=ID;
        this.fname=fname;
        this.address=address;
        this.gender=gender;
        this.mobile=mobile;
        this.nic=nic;
        this.vehicleno=vehicleno;
        this.manufacturedyear=manufacturedyear;
        this.modelname=modelname;
    
        
    }

    public int getID() {
        return ID;
    }

    public int getMobile() {
        return mobile;
    }

    public int getManufacturedyear() {
        return manufacturedyear;
    }

    public String getFname() {
        return fname;
    }

    public String getAddress() {
        return address;
    }

    public String getGender() {
        return gender;
    }

    public String getNic() {
        return nic;
    }

    public String getVehicleno() {
        return vehicleno;
    }

    public String getModelname() {
        return modelname;
    }
    
    
    
    
    
}
