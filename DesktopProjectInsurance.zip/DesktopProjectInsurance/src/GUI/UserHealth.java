/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

/**
 *
 * @author mshamil
 */
class UserHealth {
      private int ID,mobile;
    private String fname,address,gender,nic,birthday,guardiansname,blood,surgury,alergy;
    
   
    public UserHealth(int ID,String fname,String address,String gender,int mobile,String nic,String birthday,String guardiansname,String blood,String surgury,String alergy ){
        
        this.ID=ID;
        this.fname=fname;
        this.address=address;
        this.gender=gender;
        this.mobile=mobile;
        this.nic=nic;
        this.birthday=birthday;
        this.guardiansname=guardiansname;
        this.blood=blood;
        this.surgury=surgury;
        this.alergy=alergy;
        
        
}

    public int getID() {
        return ID;
    }

    public int getMobile() {
        return mobile;
    }

    public String getFname() {
        return fname;
    }

    public String getAddress() {
        return address;
    }

    public String getGender() {
        return gender;
    }

    public String getNic() {
        return nic;
    }

    public String getBirthday() {
        return birthday;
    }

    public String getGuardiansname() {
        return guardiansname;
    }

    public String getBlood() {
        return blood;
    }

    public String getSurgury() {
        return surgury;
    }

    public String getAlergy() {
        return alergy;
    }
    
    
    
    
    
    
    
    
    
    
}