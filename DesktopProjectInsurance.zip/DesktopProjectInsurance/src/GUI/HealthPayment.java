/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

/**
 *
 * @author mshamil
 */
class HealthPayment {
    
      private int ID,mobile;
    private String fname,nic,blood,paymenttype,date,amount;

    public HealthPayment(int ID, String fname,int mobile, String nic, String blood, String paymenttype, String date, String amount) {
        this.ID = ID;
        this.mobile = mobile;
        this.fname = fname;
        this.nic = nic;
        this.blood = blood;
        this.paymenttype = paymenttype;
        this.date = date;
        this.amount = amount;
    }

    public int getID() {
        return ID;
    }

    public int getMobile() {
        return mobile;
    }

    public String getFname() {
        return fname;
    }

    public String getNic() {
        return nic;
    }

    public String getBlood() {
        return blood;
    }

    public String getPaymenttype() {
        return paymenttype;
    }

    public String getDate() {
        return date;
    }

    public String getAmount() {
        return amount;
    }
    
    
    
    
}
