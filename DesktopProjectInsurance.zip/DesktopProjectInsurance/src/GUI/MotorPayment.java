/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

/**
 *
 * @author mshamil
 */

class MotorPayment {
    

     private int ID,mobile;
    private String fname,nic,vehicleno,paymenttype,date,amount;
    
   
    public MotorPayment(int ID,String fname,String nic,String vehicleno,int mobile,String paymenttype,String date,String amount ){
       
          this.ID = ID;
        this.mobile = mobile;
        this.fname = fname;
        this.nic = nic;
        this.vehicleno = vehicleno;
        this.paymenttype = paymenttype;
        this.date = date;
        this.amount = amount;
        
        
        
        
        
        
        
    
    }

    public int getID() {
        return ID;
    }

    public int getMobile() {
        return mobile;
    }

    public String getFname() {
        return fname;
    }

    public String getNic() {
        return nic;
    }

    public String getVehicleno() {
        return vehicleno;
    }

    public String getPaymenttype() {
        return paymenttype;
    }

    public String getDate() {
        return date;
    }

    public String getAmount() {
        return amount;
    }

  
}
