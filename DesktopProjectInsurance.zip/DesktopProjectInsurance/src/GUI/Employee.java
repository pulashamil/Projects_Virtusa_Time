/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

/**
 *
 * @author mshamil
 */
class Employee {
    
     
    private int ID,mobile;
    private String name,address,birthday,nic,gender,email,possition;
    
   
    public Employee(int ID,String name,String nic,String address,String birthday,String gender,int mobile,String email,String possition ){
        
        
        this.ID=ID;
        this.name=name;
        this.address=address;
        this.birthday=birthday;
        this.gender=gender;
        this.mobile=mobile;
        this.email=email;
        this.possition=possition;
        this.nic=nic;
       
        
    }

    public int getID() {
        return ID;
    }

    public int getMobile() {
        return mobile;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getBirthday() {
        return birthday;
    }

    public String getGender() {
        return gender;
    }

    public String getEmail() {
        return email;
    }

    public String getPossition() {
        return possition;
    }
    
     public String getNic() {
        return nic;
    }
    
    
    
}
