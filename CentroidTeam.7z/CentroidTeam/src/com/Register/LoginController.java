package com.Register;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginController
 */
public class LoginController extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String date=request.getParameter("date");

		String name = null;
		String mail = null;
		String contactno = null;
		String address=null;
	String empID=null;
		String ID=null;
		// Connect to mysql and verify username password
	
		try {
			
			
			Class.forName("com.mysql.jdbc.Driver");
		 // loads driver
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/centroiddb", "root", ""); // gets a new connection
 
		PreparedStatement ps = c.prepareStatement("select * from register where username=? and password=?");
		ps.setString(1, username);
		ps.setString(2, password);
 
		ResultSet rs = ps.executeQuery();
		
		
				
		while (rs.next()) {
			ID=rs.getString("ID");
			name = rs.getString("name");
			empID = rs.getString("empID");
			mail = rs.getString("mail");

			contactno = rs.getString("contactno");
			username = rs.getString("username");
			password = rs.getString("password");

			HttpSession session = request.getSession(true); // reuse existing
			// session if exist
			// or create one
			session.setAttribute("date",date);
			session.setAttribute("ID",ID);
			session.setAttribute("name", name);
			session.setAttribute("empID", empID);
			session.setAttribute("mail", mail);
				session.setAttribute("contactno", contactno);
				session.setAttribute("username", username);
				session.setAttribute("password", password);

				session.setMaxInactiveInterval(3600); 
			 String admin1="ashan";
			 String admin2="nuwan";
			 String admin3="sanduni";
			 String admin4="thushari";

				if(username.equals(admin1)||username.equals(admin2)||username.equals(admin3)||username.equals(admin4) ){		
						response.sendRedirect("AdminDashboard.jsp");
						return;

					}else{
						response.sendRedirect("Home.jsp");
						return;
					}
		}
		response.sendRedirect("Login.jsp");
		return;
		
				
		
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
}
