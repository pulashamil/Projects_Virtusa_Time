package com.Register;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserDataServlet
 */
public class EditProfile extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String empID = request.getParameter("empID");
		String name = request.getParameter("name");
		String mail = request.getParameter("mail");
		String contactno = request.getParameter("contactno");
		String username = request.getParameter("username");
		String password = request.getParameter("password");



		// validate given input
		if (empID.isEmpty() ) {
			RequestDispatcher rd = request.getRequestDispatcher("Home.jsp");
			out.println("<font color=red>Please fill all the fields</font>");
			rd.include(request, response);
		} else {
			// inserting data into mysql database
			// create a test database and student table before running this
			// to create table - create table student(name varchar(100),
			// userName varchar(100), pass varchar(100), addr varchar(100), age
			// int, qual varchar(100), percent varchar(100), year varchar(100));
			try {
				Class.forName("com.mysql.jdbc.Driver");
				// loads mysql driver

				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/centroiddb", "root", ""); // create
																														// new
																														// connection
																														// with
																														// test
																														// database

				String query = "update register set name=(?),contactno=(?),username=(?),password=(?) where empID=?";

				PreparedStatement ps = con.prepareStatement(query); // generates
																	// sql query

				ps.setString(1, name);
				ps.setString(2, contactno);
				ps.setString(3, username);
				ps.setString(4, password);
				ps.setString(5, empID);




				ps.executeUpdate(); // execute it on test database
				System.out.println("successfuly inserted");
				ps.close();
				con.close();
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
			rd.forward(request, response);
		}
	}
}
